import json
import csv
import re
from pathlib import Path

json_path = Path(
    r"C:\Users\35807\AppData\LocalLow\High North Studios\SKALD_ Against the Black Priory"
    r"\Custom Projects\DevelopmentBuild\Data\SkaldProject.json"
)

csv_path = Path("skald_json_translated_all.csv")
backup_path = json_path.with_suffix(".before_translate_and_cost_fix.json")

data = json.loads(json_path.read_text(encoding="utf-8-sig"))


def get_by_path(root, path):
    x = root
    parts = re.findall(r'\.?([A-Za-z0-9_]+)|\[(\d+)\]', path.replace("root", "", 1))

    for key, idx in parts:
        if key:
            x = x[key]
        else:
            x = x[int(idx)]

    return x


# 先备份
backup_path.write_text(json_path.read_text(encoding="utf-8-sig"), encoding="utf-8")


# 1. 写回 CSV 翻译
translated = 0

with csv_path.open("r", encoding="utf-8-sig", newline="") as f:
    r = csv.DictReader(f)

    for row in r:
        trans = row.get("translate", "")
        if not trans.strip():
            continue

        path = row["path"]
        field = row["field"]

        parent_path = path.rsplit(".", 1)[0]
        parent = get_by_path(data, parent_path)
        parent[field] = trans

        translated += 1


# 2. 修复 spellContainer 的 resourceType 空值
cost_fixed = 0

for x in data["abilityContainers"]["spellContainer"]["list"]:
    if x.get("useCost", 0) > 0 and not x.get("resourceType", ""):
        x["resourceType"] = "ATT_Attunement"
        cost_fixed += 1


# 3. 检查仍有问题的 active ability
bad = []

for cname in ["combatManeuverContainer", "spellContainer", "triggeredAbilityContainer"]:
    for x in data["abilityContainers"][cname]["list"]:
        if x.get("useCost", 0) > 0 and not x.get("resourceType", ""):
            bad.append((cname, x.get("id"), x.get("title"), x.get("useCost"), x.get("resourceType")))


# 4. 写回 JSON
json_path.write_text(
    json.dumps(data, ensure_ascii=True, indent=2),
    encoding="utf-8"
)


print("translated:", translated)
print("fixed spell resourceType:", cost_fixed)
print("bad:", len(bad))

for row in bad[:30]:
    print(row)

print("backup:", backup_path)
print("wrote:", json_path)