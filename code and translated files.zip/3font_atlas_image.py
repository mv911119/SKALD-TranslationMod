# -*- coding: utf-8 -*-
"""
SKALD Chinese language pack all-in-one builder

一键流程：
1) 默认只读取 skald_json_translated.csv 与 translations/Main Menu.csv 的 translate 列，收集所有用到的字符
2) 保留现有 language_pack.json 的 characterChart，不重排旧 index
3) 清理错误进入 characterChart 的空格/换行/控制字符/基础英文符号
4) 只把缺失字符追加到 max(index)+1
5) 按 ChineseTraslation.md 的字体参数直接重建 fonts/*.png
5) Logo.png 不处理
6) 默认只预览输出到 rebuild_preview；加 --apply 才备份并覆盖

依赖：
    python -m pip install pillow

推荐：
    先从原版 Chinese 语言包恢复 language_pack.json 和 fonts/
    再运行本脚本。不要用已经被“从 90 重排”搞乱过的 language_pack.json。
"""

import argparse
import csv
import json
import math
import shutil
from datetime import datetime
from pathlib import Path
from typing import Dict, Tuple, Optional

from PIL import Image, ImageDraw, ImageFont


DEFAULT_PACK = Path(r"C:\Program Files (x86)\Steam\steamapps\common\SKALD Against the Black Priory\BepInEx\plugins\LanguagePacks\Chinese")

# 0-89 基础字符。不要改顺序。
BASE_0_89 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmnopqrstuvwxyz!0123456789.,:/%-+?\'"()=*_[]#<>;{}|  '

EXTRA_CHARS = '。，！？；：《》“”‘’（）—…、·『』【】《》「」'

# filename: (cell_w, cell_h, offset_x, offset_y, color_rgb, font_kind)
# 根据 ChineseTraslation.md 参数整理。Logo.png 故意不放进来。
FONT_RULES: Dict[str, Tuple[int, int, int, int, Tuple[int, int, int], str]] = {
    "BigFont.png": (16, 16, 0, 0, (0, 0, 0), "wqy"),
    "IlluminatedFont.png": (16, 16, 0, 0, (237, 241, 113), "wqy"),
    "IlluminatedFontLarge.png": (20, 20, 0, 0, (0, 0, 0), "wqy"),
    "InsularHuge.png": (20, 20, 0, 0, (0, 0, 0), "wqy"),
    "InsularMedium.png": (16, 16, 0, 0, (0, 0, 0), "wqy"),
    "InsularTiny.png": (10, 10, 0, 0, (0, 0, 0), "fusion"),
    "MedievalHuge.png": (28, 24, 0, -4, (237, 241, 113), "wqy"),
    "MedievalHugeThin.png": (28, 24, 0, -4, (0, 0, 0), "wqy"),
    "MedievalMedium.png": (20, 20, 0, 0, (0, 0, 0), "wqy"),
    "MediumFont.png": (16, 16, 0, 0, (0, 0, 0), "wqy"),
    "MediumFontBlue.png": (16, 16, 0, 0, (117, 206, 200), "wqy"),
    "TinyFont.png": (10, 10, 0, 0, (178, 178, 178), "fusion"),
    "TinyFontCapitalized.png": (10, 10, 0, 0, (178, 178, 178), "fusion"),
    "TinyFontCapitalizedYellow.png": (10, 10, 0, 0, (237, 241, 113), "fusion"),
    "TinyFontFat.png": (10, 10, 0, 0, (0, 0, 0), "fusion"),
    "TinyFontTall.png": (10, 10, 0, 0, (237, 241, 113), "fusion"),
    "TinyFontTallCapitalized.png": (10, 10, 0, 0, (237, 241, 113), "fusion"),
    "TinyFontYellow.png": (10, 10, 0, 0, (237, 241, 113), "fusion"),
}


def is_custom_glyph_char(c: str) -> bool:
    """Return True only for characters that should be put into characterChart.
    ASCII/base chars, normal spaces, newlines, tabs and other control chars must not be mapped.
    """
    if not c:
        return False
    if c in BASE_0_89:
        return False
    if c in {"\r", "\n", "\t", "\ufeff", "\u200b", "\ufffd"}:
        return False
    if c.isspace():
        return False
    if ord(c) < 32 or ord(c) == 127:
        return False
    return True


def clean_chart(chart: Dict[str, int]) -> Tuple[Dict[str, int], Dict[str, int]]:
    kept = {}
    removed = {}
    for k, v in chart.items():
        if len(k) != 1 or not is_custom_glyph_char(k):
            removed[k] = v
        else:
            kept[k] = v
    return kept, removed


def read_csv_file_chars(csv_path: Path) -> str:
    chars = []
    seen = set()

    if not csv_path.exists():
        print(f"skip missing csv: {csv_path}")
        return ""

    with open(csv_path, "r", encoding="utf-8-sig", newline="") as f:
        r = csv.DictReader(f)
        if not r.fieldnames or "translate" not in r.fieldnames:
            print(f"skip no translate column: {csv_path}")
            return ""

        for row in r:
            for c in row.get("translate", ""):
                if is_custom_glyph_char(c) and c not in seen:
                    seen.add(c)
                    chars.append(c)

    print(f"read chars from: {csv_path} ({len(chars)})")
    return "".join(chars)


def merge_unique_chars(*parts: str) -> str:
    chars = []
    seen = set()
    for s in parts:
        for c in s:
            if is_custom_glyph_char(c) and c not in seen:
                seen.add(c)
                chars.append(c)
    return "".join(chars)


def find_font(pack: Path, kind: str, arg_path: Optional[str]) -> Path:
    if arg_path:
        p = Path(arg_path)
        if p.exists():
            return p
        raise FileNotFoundError(f"指定字体不存在: {p}")

    if kind == "wqy":
        patterns = [
            "*WenQuanYi*Bitmap*Song*16*.ttf",
            "*WenQuanYi*Bitmap*Song*16*.ttc",
            "*WenQuanYi*Bitmap*Song*16*.otf",
            "*wqy*16*.ttf",
            "*wqy*bitmap*song*16*.ttf",
        ]
        expected = "WenQuanYi Bitmap Song 16px.ttf"
    else:
        patterns = [
            "*fusion-pixel-10px-proportional-zh_hans*.ttf",
            "*fusion*pixel*10*zh_hans*.ttf",
            "*fusion*pixel*10*.ttf",
        ]
        expected = "fusion-pixel-10px-proportional-zh_hans.ttf"

    roots = [
        pack,
        pack / "fonts",
        Path.home() / "Downloads",
        Path.home() / "AppData" / "Local" / "Microsoft" / "Windows" / "Fonts",
        Path(r"C:\Windows\Fonts"),
    ]

    for root in roots:
        if not root.exists():
            continue

        for pat in patterns:
            if root == pack:
                found = list(root.rglob(pat))
            else:
                found = list(root.glob(pat))
            if found:
                return found[0]

    raise FileNotFoundError(f"找不到字体: {expected}。把字体放到 Chinese 目录，或用 --wqy / --fusion 指定。")


def glyph_mask(font: ImageFont.FreeTypeFont, ch: str) -> Image.Image:
    try:
        core = font.getmask(str(ch), mode="1")
        mask = Image.frombytes("L", core.size, bytes(core))
        bb = mask.getbbox()
        if not bb:
            return Image.new("L", (1, 1), 0)
        return mask.crop(bb)
    except Exception:
        dummy = Image.new("L", (128, 128), 0)
        d = ImageDraw.Draw(dummy)
        bbox = d.textbbox((0, 0), ch, font=font)
        w = max(1, bbox[2] - bbox[0] + 4)
        h = max(1, bbox[3] - bbox[1] + 4)
        img = Image.new("L", (w, h), 0)
        d = ImageDraw.Draw(img)
        d.text((2 - bbox[0], 2 - bbox[1]), ch, font=font, fill=255)
        img = img.point(lambda v: 255 if v >= 128 else 0)
        bb = img.getbbox()
        return img.crop(bb) if bb else Image.new("L", (1, 1), 0)


def build_chars_by_index(chart: Dict[str, int]) -> str:
    max_idx = max([89] + [int(v) for v in chart.values()])
    slots = ["\0"] * (max_idx + 1)

    for i, c in enumerate(BASE_0_89):
        slots[i] = c

    for c, idx in chart.items():
        idx = int(idx)
        if idx >= 0:
            slots[idx] = c

    return "".join(slots)


def generate_atlas(
    chars: str,
    font_path: Path,
    font_size: int,
    cell_w: int,
    cell_h: int,
    offset_x: int,
    offset_y: int,
    rgb: Tuple[int, int, int],
    columns: int = 9,
) -> Image.Image:
    rows = math.ceil(len(chars) / columns)
    width = columns * cell_w
    height = rows * cell_h

    img = Image.new("RGBA", (width, height), (0, 0, 0, 0))

    font = ImageFont.truetype(str(font_path), size=font_size)
    color = (*rgb, 255)

    for i, ch in enumerate(chars):
        if ch == "\0" or ch in {"\r", "\n", "\t"} or ch.isspace():
            continue

        col = i % columns
        row_from_bottom = i // columns
        visual_row = rows - 1 - row_from_bottom

        x0 = col * cell_w
        y0 = visual_row * cell_h

        mask = glyph_mask(font, ch)

        x = x0 + offset_x
        CENTER_CHARS = {"一"}
        LOWER_CHARS = {"-", "－", "–", "—", "―"}
        QUOTES_CHARS = {"“", "”", "‘", "’", '"', "'"}

        if ch in CENTER_CHARS:
            y = y0 + (cell_h - mask.height) // 2 + offset_y + 1
        elif ch in LOWER_CHARS:
            y = y0 + (cell_h - mask.height) // 2 + offset_y + 1.5
        elif ch in QUOTES_CHARS:
            y = y0 + (cell_h - mask.height) // 2 + offset_y  # 中线
        else:
            y = y0 + (cell_h - mask.height) + offset_y  # 普通底部对齐

        glyph = Image.new("RGBA", mask.size, color)
        img.paste(glyph, (int(x), int(y)), mask)

    return img

def backup_targets(pack: Path) -> Path:
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = pack / f"backup_before_all_in_one_{ts}"
    backup.mkdir(parents=True, exist_ok=True)

    if (pack / "language_pack.json").exists():
        shutil.copy2(pack / "language_pack.json", backup / "language_pack.json")

    if (pack / "fonts").exists():
        shutil.copytree(pack / "fonts", backup / "fonts")

    return backup


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pack", default=str(DEFAULT_PACK), help="Chinese language pack directory")
    ap.add_argument("--json-csv", default="skald_json_translated_all.csv", help="translated SkaldProject export CSV; uses translate column")
    ap.add_argument("--menu-csv", default=None, help="Main Menu.csv path; default: <pack>/translations/Main Menu.csv")
    ap.add_argument("--wqy", default=None, help="WenQuanYi Bitmap Song 16px.ttf path")
    ap.add_argument("--fusion", default=None, help="fusion-pixel-10px-proportional-zh_hans.ttf path")
    ap.add_argument("--columns", type=int, default=9)
    ap.add_argument("--apply", action="store_true", help="backup and overwrite language_pack.json and fonts/*.png")
    args = ap.parse_args()

    pack = Path(args.pack)
    translations_dir = pack / "translations"
    json_csv = Path(args.json_csv)
    menu_csv = Path(args.menu_csv) if args.menu_csv else translations_dir / "Main Menu.csv"
    fonts_dir = pack / "fonts"
    pack_json = pack / "language_pack.json"

    if not translations_dir.exists():
        raise FileNotFoundError(translations_dir)
    if not fonts_dir.exists():
        raise FileNotFoundError(fonts_dir)
    if not pack_json.exists():
        raise FileNotFoundError(pack_json)

    with open(pack_json, "r", encoding="utf-8-sig") as f:
        data = json.load(f)

    raw_chart = {str(k): int(v) for k, v in data.get("characterChart", {}).items()}
    chart, removed_chart = clean_chart(raw_chart)

    csv_chars = merge_unique_chars(
        read_csv_file_chars(json_csv),
        read_csv_file_chars(menu_csv),
        EXTRA_CHARS,
    )
    missing = [c for c in csv_chars if c not in chart]

    start = max([89] + list(chart.values())) + 1
    for i, c in enumerate(missing):
        chart[c] = start + i

    data["fontFilesPath"] = "fonts"
    data["translationFilesPath"] = "translations"
    data["characterChart"] = chart

    full_chars = build_chars_by_index(chart)

    wqy = find_font(pack, "wqy", args.wqy)
    fusion = find_font(pack, "fusion", args.fusion)

    if args.apply:
        backup = backup_targets(pack)
        out_root = pack
        out_fonts = fonts_dir
        out_pack = pack_json
        print("backup:", backup)
    else:
        out_root = pack / "rebuild_preview"
        out_fonts = out_root / "fonts"
        out_pack = out_root / "language_pack.json"
        out_fonts.mkdir(parents=True, exist_ok=True)

        for p in fonts_dir.glob("*.png"):
            if p.name not in FONT_RULES:
                shutil.copy2(p, out_fonts / p.name)

        print("preview:", out_root)

    print("pack:", pack)
    print("json csv:", json_csv)
    print("menu csv:", menu_csv)
    print("wqy:", wqy)
    print("fusion:", fusion)
    print("selected csv custom chars:", len(csv_chars))
    print("removed whitespace/base/control chart entries:", len(removed_chart))
    if removed_chart:
        print("removed entries repr:", ", ".join(repr(k) for k in list(removed_chart)[:20]))
    print("existing chart kept:", len(chart) - len(missing))
    print("missing added:", len(missing))
    print("start index:", start if missing else "(none)")
    print("last index:", max([89] + list(chart.values())))
    print("full slots:", len(full_chars))

    for name, (cell_w, cell_h, ox, oy, rgb, kind) in FONT_RULES.items():
        if not (fonts_dir / name).exists():
            print("skip missing:", name)
            continue

        font_path = wqy if kind == "wqy" else fusion
        font_size = 16 if kind == "wqy" else 10

        img = generate_atlas(
            chars=full_chars,
            font_path=font_path,
            font_size=font_size,
            cell_w=cell_w,
            cell_h=cell_h,
            offset_x=ox,
            offset_y=oy,
            rgb=rgb,
            columns=args.columns,
        )

        out = out_fonts / name
        out.parent.mkdir(parents=True, exist_ok=True)
        img.save(out, "PNG", compress_level=0)
        print("wrote:", out)

    out_pack.parent.mkdir(parents=True, exist_ok=True)
    with open(out_pack, "w", encoding="utf-8-sig") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    (out_root / "ChineseString.txt").write_text(csv_chars, encoding="utf-8-sig")
    (out_root / "missing_chars.txt").write_text("".join(missing), encoding="utf-8-sig")

    print("wrote:", out_pack)
    print("wrote:", out_root / "ChineseString.txt")
    print("wrote:", out_root / "missing_chars.txt")
    print("Logo.png unchanged")
    print("done")


if __name__ == "__main__":
    main()
