from pathlib import Path

src = Path(r"SkaldProject_en.dat")

out = Path(
    r"C:\Users\35807\AppData\LocalLow\High North Studios\SKALD_ Against the Black Priory"
    r"\Custom Projects\DevelopmentBuild\Data\SkaldProject.json"
)

b = src.read_bytes()

json_start = b.find(b"{")
json_end = b.rfind(b"}") + 1

body = b[json_start:json_end]

out.parent.mkdir(parents=True, exist_ok=True)
out.write_bytes(body)

print("wrote:", out)
print("json_start:", json_start)
print("size:", len(body))
print("starts:", body[:20])