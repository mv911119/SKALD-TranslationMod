import json
import csv
import re
from pathlib import Path
from collections import Counter

json_path = Path(
    r"C:\Users\35807\AppData\LocalLow\High North Studios\SKALD_ Against the Black Priory"
    r"\Custom Projects\DevelopmentBuild\Data\SkaldProject.json"
)

out_csv = Path("skald_json_to_translate.csv")

FIELDS = {
    "title",
    "description",
    "content",
    "option",
    "begunLogString",
    "secondaryDescription",
    "completedLogString"
}

BARK_COMMANDS = {
    "addVocalBark",
    "addVocalBarkLocal",
    "addPositiveBark"
}

data = json.loads(json_path.read_text(encoding="utf-8-sig"))

rows = []

def looks_like_text(s):
    if not isinstance(s, str):
        return False
    if not s.strip():
        return False
    if not re.search(r"[A-Za-z]{2,}", s):
        return False
    if re.fullmatch(r"[A-Z0-9_]+", s):
        return False
    if s.startswith("{") and s.endswith("}"):
        return False
    return True

def extract_barks(s, path, field):
    for m in re.finditer(r"\{([^{}|]+)\|([^{}]*)\}", s):
        cmd = m.group(1)
        args = m.group(2)

        if cmd not in BARK_COMMANDS:
            continue

        parts = args.split(";")

        for i, part in enumerate(parts):
            part = part.strip()

            if looks_like_text(part):
                rows.append({
                    "path": path,
                    "field": field,
                    "kind": "trigger",
                    "command": cmd,
                    "arg_index": i,
                    "original": part,
                    "translate": "",
                })

def walk(x, path="root"):
    if isinstance(x, dict):
        for k, v in x.items():
            p = f"{path}.{k}"

            if k in FIELDS and isinstance(v, str) and v.strip():
                rows.append({
                    "path": p,
                    "field": k,
                    "kind": "field",
                    "command": "",
                    "arg_index": "",
                    "original": v,
                    "translate": "",
                })

            if isinstance(v, str) and any(cmd in v for cmd in BARK_COMMANDS):
                extract_barks(v, p, k)

            walk(v, p)

    elif isinstance(x, list):
        for i, v in enumerate(x):
            walk(v, f"{path}[{i}]")

walk(data)

with out_csv.open("w", encoding="utf-8-sig", newline="") as f:
    w = csv.DictWriter(
        f,
        fieldnames=[
            "path",
            "field",
            "kind",
            "command",
            "arg_index",
            "original",
            "translate",
        ]
    )
    w.writeheader()
    w.writerows(rows)

print("exported:", len(rows))
print("wrote:", out_csv)
print(Counter((r["command"] or r["field"]) for r in rows))